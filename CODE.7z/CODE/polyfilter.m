function C = polyfilter( c, win, order)

n = zeros(size(c)) ;
r = n ;

for k = 1:numel(c)-win
    p = polyfit(k:k+win,c(k:k+win),order) ;
    y = polyval(p,k:k+win);
    n(k:k+win) = n(k:k+win)+1 ;
    r(k:k+win) = r(k:k+win) + y ;
end
C = r./n ;