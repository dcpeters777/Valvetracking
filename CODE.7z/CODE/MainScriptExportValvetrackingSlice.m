
%------------------------------------------------------------
%       Copyright Jerome Lamy, 9/29/2022
%
%-------------------------------------------------------------

%Inputs: SET which contains right ventricular 2ch and 4ch cine images, 
%tricuspid valve insertion point locations on each image. 
%Information on resolution, position and orientation of each slice. 


%Output: plots that describe phase-dependent position/orientation of the valvular slice plane.

% Most importantly, a file increment_slice_position.txt, which provides  over the entire
%cardiac cycle (interpolated to 500 frames) the valve center position, and
%the valve normal vector, in physical coordinate system. 

% For each phase 12 values are generated.  Values 10,11,12 are the (X,y,z) valve
% center location in physical coords.   Values 7,8,9 are the x, y,z values
% defining the normal to the valve-plane.   These can be used in a pulse
% sequence. 

%This code loads a structure SET 
% SET can be generated using Segment
%found here  https://github.com/Cardiac-MR-Group-Lund/segment-open
%code, with a TVnet plugin https://github.com/ra-gonzales/TVnet
% SET(1), and SET(2) contain data for 4ch cine and RV 2ch cine
% including the valve insertion point locations (obtained by TVnet). 
% and the geometry. 


% 
% SET(1).ResolutionX—dicom pixel size (mm)
% SET(1).ResolutionY—dicom pixel size (mm)
% SET(1).IM--image data
% SET(1).Point.X—Xlocation of 60  points –30 frames for 2 points defining valve in pixels ( not mm.)
% SET(1).Point.Y –Ylocation of 60 points. 
% SET(1).XSize—dimension in x in pixels
% SET(1).YSize—dimension in y in pixels
% SET(1).ImagePosition (Physical coordinates of the upper left hand of the image DICOM (0020) (0032))
% SET(1).ImageOrientation DICOM(0020) (0037)—the rotation matrix  to convert from the logical to physical coordinates. 

load ../Data/SET  % SET is the dataset in the folder Data --load it.   
global ValveTracking;

%-- Ask for selected 2 and 4 chambers view
id_4ch = 1 ;
id_2ch = 2 ;

ValveTracking.id_4ch = id_4ch ;
ValveTracking.id_2ch = id_2ch ;


%-- Extract normal and positions of vector
[ nOr_4ch, cV_4ch ] = ExtractValveNormCenter( id_4ch ) ;
[ nOr_2ch, cV_2ch ] = ExtractValveNormCenter( id_2ch ) ;

%-- Combine Geometry
ValveCenter = (cV_4ch + cV_2ch )/2 ;

m = [] ;
for ka = 1 : size(nOr_4ch)
    normalVector = cross( nOr_4ch(ka,1:3), nOr_2ch(ka,1:3) ) ;
    normalVector = normalVector./norm(normalVector) ;
    m(:,:,ka) = -[ nOr_4ch(ka,4:6)' nOr_4ch(ka,1:3)' normalVector(:) ]  ; % on touche pas au inplan. a priori on s'en sert plus
end

%-- Inline Data:
line = [] ;
for ka = 1 : size(nOr_4ch)
    line(ka,:) = [ reshape(m(:,:,ka),1,9) ValveCenter(ka,:)*1000 ] ;
    % valvecenter x 1000 because it was divided by 1000 in
    % ExtractNormCenter.
end

figure (102)
set(gcf,'Name','Raw Line data')
subplot 121
plot(line(:,7:9),'x-')
title('Normal to the Valve plane')
subplot 122
plot(line(:,10:12),'x-')
title('Valve center position' )

%-- Light Smooth+modulo correction
for k = 1 : 1
    delt = 3 ;
    for iter = 1 :15
        tL = polyfilter(line(:,k)', 28, 5)' ;
        mDiff = abs(tL - line(:,k)) ;
        line(mDiff>delt*mean(mDiff),k) = tL(mDiff>delt*mean(mDiff)) ;
    end
end

figure (103)
set(gcf,'Name','ModCor Line data')
subplot 121
plot(line(:,7:9),'x-')
title('Normal to the Valve plane')
subplot 122
plot(line(:,10:12),'x-')
title('Valve center position' )

%-- Light Smooth
for k = 1 : 12
    l = [ line(:,k)' line(:,k)' line(:,k)' ] ;
    nL = polyfilter(l, 10, 4)' ;
    line(:,k) = nL(size(line,1)+1:2*size(line,1)) ;
end

figure (104)
set(gcf,'Name','Filt Line data')
subplot 121
plot(line(:,7:9),'x-')
title('Normal to the Valve plane')
subplot 122
plot(line(:,10:12),'x-')
title('Valve center position' )


%-- Interpolation
line = easyInterp(line,500) ;
for k = 1 : 500
    line(k,1:3) = line(k,1:3) / norm(line(k,1:3)) ;
    line(k,4:6) = line(k,4:6) / norm(line(k,4:6)) ;
    line(k,7:9) = line(k,7:9) / norm(line(k,7:9)) ;
end

figure (105)
set(gcf,'Name','InterpNorm Line data')
subplot 121
plot(line(:,7:9),'x-')
title('Normal to the Valve plane')
subplot 122
plot(line(:,10:12),'x-')
title('Valve center position' )

figure (106)
set(gcf,'Name','Valve center displacement and angulation')
subplot 211
d = sum(((line(:,10:12) - repmat(line(1,10:12),size(line,1),1)).^2),2).^.5 ;
xP = 0:1/(length(d)-1):1 ;
plot(xP,smoothn(-d,50),'LineWidth',4,'Color','k')
% title('Valve displacement [mm]')
grid on
grid minor
hA = gca ;
hA.GridAlpha = .5 ;
hA.MinorGridAlpha = .6 ;
xlabel('Cardiac Cycle')
ylabel('Distance [mm]')
set(gca,'FontWeight','bold','FontSize',20)

subplot 212
[azimuth,elevation,r] = cart2sph(line(:,7),line(:,8),line(:,9)) ;
hold off
plot(xP,smoothn(azimuth-azimuth(1),50),'LineWidth',4,'Color','k','LineStyle','-')
hold on
plot(xP,smoothn(elevation-elevation(1),50),'LineWidth',4,'Color','k','LineStyle','--')
hold off
% title('Valve normal azimuth and elevation variation [radian]' )
grid on
grid minor
hA = gca ;
hA.GridAlpha = .5 ;
hA.MinorGridAlpha = .6 ;
legend('Azimuth variation','Elevation variation')
set(gcf,'renderer','painters');
xlabel('Cardiac Cycle')
ylabel('Angles [rad]')

set(gca,'FontWeight','bold','FontSize',20)

figure (107)
rT = (SET(id_4ch).TIncr + SET(id_2ch).TIncr)/2*30/500 ;
set(gcf,'Name','Valve center displacement and angulation')
subplot 211
d = sum(((line(:,10:12) - repmat(line(1,10:12),size(line,1),1)).^2),2).^.5 ;
xP = 0:1/(length(d)-1):1 ;
plot(xP,gradient(smoothn(-d,1600))/rT/10,'LineWidth',4,'Color','k')
hold on
val = gradient(smoothn(-d,1600))/rT/10 ;
[~, id1] = max(-gradient(smoothn(-d,1600))/rT/10) ;
[~, id] = findpeaks(val) ;
plot(xP(id1),val(id1),'rx')
plot(xP(id),val(id),'rx')
hold off


text(xP(id1),val(id1),['(' num2str(xP(id1)) ',' num2str(val(id1)) ')'])
text(xP(id(1)),val(id(1)),['(' num2str(xP(id(1))) ',' num2str(val(id(1))) ')'])
text(xP(id(2)),val(id(2)),['(' num2str(xP(id(2))) ',' num2str(val(id(2))) ')'])

% title('Valve displacement [mm]')
grid on
grid minor
hA = gca ;
hA.GridAlpha = .5 ;
hA.MinorGridAlpha = .6 ;
xlabel('Cardiac Cycle')
ylabel('Valve center velocity [cm/s]')
set(gca,'FontWeight','bold','FontSize',20)

subplot 212
[azimuth,elevation,r] = cart2sph(line(:,7),line(:,8),line(:,9)) ;
hold off
plot(xP,gradient(smoothn(azimuth-azimuth(1),1600))/rT,'LineWidth',4,'Color','k','LineStyle','-')
hold on
plot(xP,gradient(smoothn(elevation-elevation(1),1600))/rT,'LineWidth',4,'Color','k','LineStyle','--')
hold off
% title('Valve normal azimuth and elevation variation [radian]' )
grid on
grid minor
hA = gca ;
hA.GridAlpha = .5 ;
hA.MinorGridAlpha = .6 ;
legend('Azimuth variation','Elevation variation')
set(gcf,'renderer','painters');
xlabel('Cardiac Cycle')
ylabel('Valve plane normal angles [rad/s]')

set(gca,'FontWeight','bold','FontSize',20)

%-- Visu exported
ha = showValve3D(line, ValveTracking) ;

%-- Save TXT
% if ~isfield(ValveTracking,'folderPath')
    ValveTracking.folderPath = uigetdir('Pick a directory for saving the valvetracking file') ;
% end
fileID = fopen([ValveTracking.folderPath filesep 'increment_slice_position.txt'],'w');
fprintf(fileID,'%1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f %1.6f \r\n',line');
fclose(fileID);

[di, idMax] = max(abs(smoothn(-d,50))) ;
az = smoothn(azimuth-azimuth(1),50) ;
el = smoothn(elevation-elevation(1),50) ;
[ di az(idMax) el(idMax) ]


function cI = easyInterp(c, rate )
x = (0:size(c,1)-1)/(size(c,1)-1)' ;
xI = 0: 1/(rate-1) : 1 ;

cI = interp1( x, c, xI','linear') ;
end



function C = polyfilter( c, win, order)

n = zeros(size(c)) ;
r = n ;

for k = 1:numel(c)-win
    p = polyfit(k:k+win,c(k:k+win),order) ;
    y = polyval(p,k:k+win);
    n(k:k+win) = n(k:k+win)+1 ;
    r(k:k+win) = r(k:k+win) + y ;
end
C = r./n ;
end

