function borned = autoContrast(I, th)

if ~exist('th')
    th = [.1 .95] ;
end

I = double (I) ;

[counts,centers] = hist(I(:), numel(I)) ;
c = cumsum(counts)/sum(counts) ;

borned = [centers(find(c>th(1),1)) centers(find(c>th(2),1))] ;