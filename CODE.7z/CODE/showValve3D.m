function ha = showValve3D(line, ValveTracking)
%-- Tracking Visualisation 2ch and 4ch 3D
%------------------------------------------------------------
%       Copyright Jerome Lamy, 9/29/2022
%
%-------------------------------------------------------------
%this is a visualization tool
%
global SET 

%
line = easyInterp(line,30) ;
initPhase = 1 ;

%
id1 = ValveTracking.id_4ch ;

ori_dcm1 = SET(id1).ImageOrientation ;
pos_dcm1 = SET(id1).ImagePosition ;
res_dcm1 = SET(id1).ResolutionX ;

I1 = SET(id1).IM ;

xx=(0:size(I1,1)-1)*res_dcm1/1000;
yy=(0:size(I1,2)-1)*res_dcm1/1000;
[YY,XX] = meshgrid(xx,yy);

X1 = XX*ori_dcm1(1) + YY*ori_dcm1(4) + pos_dcm1(1)/1000;
Y1 = XX*ori_dcm1(2) + YY*ori_dcm1(5) + pos_dcm1(2)/1000;
Z1 = XX*ori_dcm1(3) + YY*ori_dcm1(6) + pos_dcm1(3)/1000;

%
id2 = ValveTracking.id_2ch ;

ori_dcm2 = SET(id2).ImageOrientation ;
pos_dcm2 = SET(id2).ImagePosition ;
res_dcm2 = SET(id2).ResolutionX ;

I2 = SET(id2).IM ;

xx = (0:size(I2,1)-1)*res_dcm2/1000;
yy = (0:size(I2,2)-1)*res_dcm2/1000;
[YY,XX] = meshgrid(xx,yy);

X2 = XX*ori_dcm2(1) + YY*ori_dcm2(4) + pos_dcm2(1)/1000;
Y2 = XX*ori_dcm2(2) + YY*ori_dcm2(5) + pos_dcm2(2)/1000;
Z2 = XX*ori_dcm2(3) + YY*ori_dcm2(6) + pos_dcm2(3)/1000;


%
figure(101)
ha = subplottight(1,1,1) ;
hold off
plan1 = surf(ha,X1,Y1,Z1,double(I1(:,:,initPhase))',...
    'FaceColor','texturemap',...
    'EdgeColor','none',...
    'FaceAlpha',.75,...
    'CDataMapping','scaled') ;
hold on
plan2 = surf(ha,X2,Y2,Z2,double(I2(:,:,initPhase))',...
    'FaceColor','texturemap',...
    'EdgeColor','none',...
    'FaceAlpha',.75,...
    'CDataMapping','scaled') ;
colormap gray
axis equal
borned = autoContrast([I1(:);I2(:)]) ;
caxis(borned)

%
P = line(:,10:12)/1000 ;
plot3(ha,P(1,1),P(1,2),P(1,3),'rx')
n1 = cross(ori_dcm1(1:3),ori_dcm1(4:6)) ;
n2 = cross(ori_dcm2(1:3),ori_dcm2(4:6)) ;
p = P ;
for k = 1 : 10
    dP1 = n1(1)*(p(:,1)-pos_dcm1(1)/1000)+n1(2)*(p(:,2)-pos_dcm1(2)/1000)+n1(3)*(p(:,3)-pos_dcm1(3)/1000) ;
    p = p - repmat(dP1,1,3).*repmat(n1,30,1);
    dP2 = n2(1)*(p(:,1)-pos_dcm2(1)/1000)+n2(2)*(p(:,2)-pos_dcm2(2)/1000)+n2(3)*(p(:,3)-pos_dcm2(3)/1000) ;
    p = p - repmat(dP2,1,3).*repmat(n2,30,1);
end
centerV = plot3(ha,p(initPhase,1),p(initPhase,2),p(initPhase,3),'yo') ;

%
plan1_P1 = ValveTracking.points(ValveTracking.id_4ch).P1 ;
plan1_P2 = ValveTracking.points(ValveTracking.id_4ch).P2 ;
plan2_P1 = ValveTracking.points(ValveTracking.id_2ch).P1 ;
plan2_P2 = ValveTracking.points(ValveTracking.id_2ch).P2 ;

valve1 = plot3(ha,[plan1_P1(initPhase,1) plan1_P2(initPhase,1)],[plan1_P1(initPhase,2) plan1_P2(initPhase,2)],[plan1_P1(initPhase,3) plan1_P2(initPhase,3)],'go-') ;
valve2 = plot3(ha,[plan2_P1(initPhase,1) plan2_P2(initPhase,1)],[plan2_P1(initPhase,2) plan2_P2(initPhase,2)],[plan2_P1(initPhase,3) plan2_P2(initPhase,3)],'go-') ;

dV1 =  plan1_P1 - plan1_P2 ;
dVn = cross(ori_dcm1(1:3),ori_dcm1(4:6)) ;
for k = 1 : size(dV1,1)
    nValve1(:,k) = cross(dV1(k,:)/norm(dV1(k,:)),dVn) ;
end
nOr1 = ExtractValveNormCenter( ValveTracking.id_2ch ) ;

dV2 =  plan2_P1 - plan2_P2 ;
dVn = cross(ori_dcm2(1:3),ori_dcm2(4:6)) ;
for k = 1 : size(dV2,1)
    nValve2(:,k) = cross(dV2(k,:)/norm(dV2(k,:)),dVn) ;
end
nOr2 = ExtractValveNormCenter( ValveTracking.id_2ch ) ;

for k = 1 : length(dV1)
    dV1(k,:) = dV1(k,:) / norm(dV1(k,:)) ;
    dV2(k,:) = dV2(k,:) / norm(dV2(k,:)) ;
    nValve(:,k) = cross(dV1(k,:),dV2(k,:)) ;
    nV = cross(nOr1(k,4:6), nOr1(k,1:3) ) ;
    nV2 = cross(nOr2(k,4:6), nOr2(k,1:3) ) ;
    s = sign(sum(cross(nOr2(1,4:6), nOr2(1,1:3) ).*cross(nOr1(1,4:6), nOr1(1,1:3) ))) ;
    nV2 = s * nV2 ;
    nValvebis(:,k) = (nV + nV2)/2 ;
end

nV1 = [] ;
nV2 = [] ;
t = (-200:200)/1000 ;
for k = 1 : 30
    nV1(:,k) = cross(n1, nValve(:,k)) ;
    nV2(:,k) = cross(n2, nValve(:,k)) ;

    r1(:,:,k) = repmat(p(k,:),length(t),1) + repmat(t',1,3).* repmat(nV1(:,k)',length(t),1) ;
    r2(:,:,k) = repmat(p(k,:),length(t),1) + repmat(t',1,3).* repmat(nV2(:,k)',length(t),1) ;
    r3(:,:,k) = repmat(p(k,:),length(t),1) + repmat(t',1,3).* repmat(nValve(:,k)',length(t),1) ;
    r4(:,:,k) = repmat(p(k,:),length(t),1) + repmat(t',1,3).* repmat(nValvebis(:,k)',length(t),1) ;
end

pValve1 = plot3(r1(:,1,initPhase),r1(:,2,initPhase),r1(:,3,initPhase),'r','LineWidth',2) ;
pValve2 = plot3(r2(:,1,initPhase),r2(:,2,initPhase),r2(:,3,initPhase),'r','LineWidth',2) ;
nValve1 = plot3(r3(:,1,initPhase),r3(:,2,initPhase),r3(:,3,initPhase),'g','LineWidth',2) ;

%
set(101,'WindowScrollWheelFcn',{@CropWheelFcn,ha})
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function CropWheelFcn(hObject, eventdata,ha)

        initPhase = initPhase + eventdata.VerticalScrollCount ;

        initPhase(initPhase<1) = 1 ;
        initPhase(initPhase>size(I1,3)) = size(I1,3) ;

        set(plan1,'CData',I1(:,:,initPhase)')
        set(plan2,'CData',I2(:,:,initPhase)')

        set(valve1,'XData',[plan1_P1(initPhase,1) plan1_P2(initPhase,1)])
        set(valve1,'YData',[plan1_P1(initPhase,2) plan1_P2(initPhase,2)])
        set(valve1,'ZData',[plan1_P1(initPhase,3) plan1_P2(initPhase,3)])
        set(valve2,'XData',[plan2_P1(initPhase,1) plan2_P2(initPhase,1)])
        set(valve2,'YData',[plan2_P1(initPhase,2) plan2_P2(initPhase,2)])
        set(valve2,'ZData',[plan2_P1(initPhase,3) plan2_P2(initPhase,3)])
        set(centerV,'XData',p(initPhase,1))
        set(centerV,'YData',p(initPhase,2))
        set(centerV,'ZData',p(initPhase,3))
        set(pValve1,'XData',r1(:,1,initPhase))
        set(pValve1,'YData',r1(:,2,initPhase))
        set(pValve1,'ZData',r1(:,3,initPhase))
        set(pValve2,'XData',r2(:,1,initPhase))
        set(pValve2,'YData',r2(:,2,initPhase))
        set(pValve2,'ZData',r2(:,3,initPhase))
        set(nValve1,'XData',r3(:,1,initPhase))
        set(nValve1,'YData',r3(:,2,initPhase))
        set(nValve1,'ZData',r3(:,3,initPhase))


    end
end

function cI = easyInterp(c, rate )
x = (0:size(c,1)-1)/(size(c,1)-1)' ;
xI = 0: 1/(rate-1) : 1 ;

cI = interp1( x, c, xI','linear') ;
end

