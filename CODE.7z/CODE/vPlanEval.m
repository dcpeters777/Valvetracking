
function nOr = vPlanEval(pFreeWall, pSeptum, oriLA)

for k = 1 : size(pFreeWall,1)
    valve_vect = pFreeWall(k,:) - pSeptum(k,:) ;
    valve_vect = valve_vect/norm(valve_vect) ;
    norm_vect = cross(oriLA(1:3),oriLA(4:6)) ;

    nOr(k,:) = [ valve_vect(:)' norm_vect(:)' ] ;
end
end
