function [ nOr, cV ] = ExtractValveNormCenter( id )
%-- Extract Normal and center of the valve
%
%       Copyright Jerome Lamy, 9/29/2022
%
%-- nOr normal, cV, center valve, create this in segment from the original
%plan
global SET ValveTracking


p1 = [ SET(id).Point.Y(strcmp(SET(id).Point.Label,'P1')); SET(id).Point.X(strcmp(SET(id).Point.Label,'P1'))]' ;
p2 = [ SET(id).Point.Y(strcmp(SET(id).Point.Label,'P2')); SET(id).Point.X(strcmp(SET(id).Point.Label,'P2'))]' ;

ori_dcm = SET(id).ImageOrientation ;
pos_dcm = SET(id).ImagePosition ;
res_dcm = SET(id).ResolutionX ;

% 3d coordinates of the valves :
pv1 = (p1-1)*res_dcm / 1000 ;
pv2 = (p2-1)*res_dcm / 1000 ;

P1 = [ ...
    pv1(:,1)*ori_dcm(1) + pv1(:,2)*ori_dcm(4) + pos_dcm(1)/1000,...
    pv1(:,1)*ori_dcm(2) + pv1(:,2)*ori_dcm(5) + pos_dcm(2)/1000,...
    pv1(:,1)*ori_dcm(3) + pv1(:,2)*ori_dcm(6) + pos_dcm(3)/1000 ] ;

P2 = [ ...
    pv2(:,1)*ori_dcm(1) + pv2(:,2)*ori_dcm(4) + pos_dcm(1)/1000,...
    pv2(:,1)*ori_dcm(2) + pv2(:,2)*ori_dcm(5) + pos_dcm(2)/1000,...
    pv2(:,1)*ori_dcm(3) + pv2(:,2)*ori_dcm(6) + pos_dcm(3)/1000 ] ;

ValveTracking.points(id).P1 = P1 ;
ValveTracking.points(id).P2 = P2 ;

% And before anything, we are filtering the points :
for k = 1 : 3
    %smoothing
    l = [ P1(:,k)' P1(:,k)' P1(:,k)' ] ;
    nL = polyfilter(l, 10, 3)' ;
    P1(:,k) = nL(size(P1,1)+1:2*size(P1,1)) ;
    %smoothing
    l = [ P2(:,k)' P2(:,k)' P2(:,k)' ] ;
    nL = polyfilter(l, 10, 3)' ;
    P2(:,k) = nL(size(P1,1)+1:2*size(P1,1)) ;
end

% we only need the slice offset position so we remove the 2 first one
% and put it in the good coordinates. Orientation mat will be reordered
% at acquisition// the signs too normally !! / hopefully
cV = (P1+P2)/2 ; %center of valve

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IT IS EXPECTED THAT WE NEED TO INVERSE THE X:
% THE QUESTION IS : FOR ORIENTATION AND POSITION ?
% THE QUESTION IS : FOR ORIENTATION ONLY ?
ori_dcm(1) = - ori_dcm(1) ;
ori_dcm(4) = - ori_dcm(4) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nOr = vPlanEval(P1, P2, ori_dcm) ;

end

%%%%%%%%%%%%%%



